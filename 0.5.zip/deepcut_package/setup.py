"""
Thai word Segmentation using Convolutional Neural Network
"""

from distutils.core import setup
setup(
  name = 'deepcut',
  packages = ['deepcut'], # this must be the same as the name above
  version = '0.5',
  description = 'A Thai word tokenization library using Deep Neural Network',
  author = 'Rakpong Kittinaradorn',
  author_email = 'r.kittinaradorn@gmail.com',
  url = 'https://github.com/rkcosmos/deepcut',
  download_url = 'https://github.com/rkcosmos/deepcut/0.5.tar.gz', 
  keywords = ['thai word segmentation deep learning neural network development'],
  classifiers = ['Development Status :: 3 - Alpha'],
)
