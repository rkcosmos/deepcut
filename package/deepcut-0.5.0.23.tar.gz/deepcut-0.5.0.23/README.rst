DeepCut: A Thai word tokenization library using Deep Neural Network 

--------

To use , simply do::

import deepcut
deepcut.deepcut('ฉันอยากกินข้าว')